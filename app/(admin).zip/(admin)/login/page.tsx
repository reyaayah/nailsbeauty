"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAdminAuth } from "@/context/AdminAuthContext";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Eye, EyeOff, Sparkles, Mail, Lock, AlertTriangle } from "lucide-react";

const schema = z.object({
  email: z.string().email("Enter a valid email"),
  password: z.string().min(6, "At least 6 characters"),
});
type FormValues = z.infer<typeof schema>;

export default function LoginPage() {
  const { login } = useAdminAuth();
  const router = useRouter();
  const [showPwd, setShowPwd] = useState(false);
  const [authError, setAuthError] = useState("");

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormValues>({
    resolver: zodResolver(schema),
  });

  const onSubmit = async ({ email, password }: FormValues) => {
    setAuthError("");
    try {
      await login(email, password);
      router.replace("/admin/dashboard");
    } catch (err: any) {
      setAuthError(err.message || "Invalid credentials.");
    }
  };

  return (
    <div className="min-h-screen flex" style={{ background: "#0f172a" }}>
      {/* Left panel — branding */}
      <div className="hidden lg:flex flex-col justify-between w-[45%] p-12" style={{ background: "linear-gradient(145deg, #1e293b 0%, #0f172a 100%)" }}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl flex items-center justify-center" style={{ background: "linear-gradient(135deg, #c2714f, #9a5239)" }}>
            <Sparkles size={18} className="text-white" />
          </div>
          <div>
            <p className="text-white font-semibold tracking-tight">Gloss & Grace</p>
            <p className="text-white/30 text-xs uppercase tracking-widest">Admin Portal</p>
          </div>
        </div>

        <div>
          <h1 className="text-4xl font-light text-white leading-snug mb-4">
            Every beautiful nail<br />
            <span style={{ color: "#c2714f" }}>starts here.</span>
          </h1>
          <p className="text-white/40 text-sm leading-relaxed max-w-xs">
            Manage your products, orders, and customers from one elegant workspace.
          </p>
        </div>

        <div className="grid grid-cols-3 gap-3">
          {["1,248 Orders", "7,834 Customers", "$82.4K Revenue"].map((stat) => (
            <div key={stat} className="rounded-xl p-3" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}>
              <p className="text-white/80 text-xs font-medium leading-snug">{stat}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="flex items-center gap-2 mb-8 lg:hidden">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: "#c2714f" }}>
              <Sparkles size={14} className="text-white" />
            </div>
            <span className="text-white font-semibold">Gloss & Grace Admin</span>
          </div>

          <div className="rounded-2xl p-8" style={{ background: "#1e293b", border: "1px solid rgba(255,255,255,0.08)" }}>
            <h2 className="text-2xl font-semibold text-white mb-1">Welcome back</h2>
            <p className="text-white/40 text-sm mb-8">Sign in to your admin account</p>

            {authError && (
              <div className="flex items-center gap-2.5 rounded-xl px-4 py-3 mb-6 text-sm" style={{ background: "rgba(239,68,68,0.12)", border: "1px solid rgba(239,68,68,0.2)", color: "#fca5a5" }}>
                <AlertTriangle size={15} className="flex-shrink-0" />
                {authError}
              </div>
            )}

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-white/70 mb-1.5">Email address</label>
                <div className="relative">
                  <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30" />
                  <input
                    type="email"
                    placeholder="admin@example.com"
                    autoComplete="email"
                    className="w-full h-11 pl-10 pr-4 rounded-xl text-sm text-white placeholder-white/25 outline-none transition-all"
                    style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)" }}
                    {...register("email")}
                  />
                </div>
                {errors.email && <p className="text-xs text-red-400 mt-1.5">{errors.email.message}</p>}
              </div>

              {/* Password */}
              <div>
                <label className="block text-sm font-medium text-white/70 mb-1.5">Password</label>
                <div className="relative">
                  <Lock size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30" />
                  <input
                    type={showPwd ? "text" : "password"}
                    placeholder="••••••••"
                    autoComplete="current-password"
                    className="w-full h-11 pl-10 pr-12 rounded-xl text-sm text-white placeholder-white/25 outline-none transition-all"
                    style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)" }}
                    {...register("password")}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPwd(!showPwd)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors"
                  >
                    {showPwd ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
                {errors.password && <p className="text-xs text-red-400 mt-1.5">{errors.password.message}</p>}
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full h-11 rounded-xl text-sm font-semibold text-white transition-all mt-2 flex items-center justify-center gap-2 disabled:opacity-60"
                style={{ background: "linear-gradient(135deg, #c2714f, #9a5239)" }}
              >
                {isSubmitting ? (
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                ) : "Sign in"}
              </button>
            </form>

            <p className="text-center text-white/25 text-xs mt-6">
              Restricted to authorized administrators only.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
