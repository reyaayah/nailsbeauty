import { AdminShell } from "@/components/layout/AdminShell";
import { AdminAuthProvider } from "@/context/AdminAuthContext";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <AdminAuthProvider>
      <AdminShell>{children}</AdminShell>
    </AdminAuthProvider>
  );
}